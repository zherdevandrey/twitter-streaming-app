package com.microservices.demo.kafka.streams.service.init;

public interface StreamsInitializer {
    void init();
}
