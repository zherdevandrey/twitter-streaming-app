package com.microservices.demo.elastic.query.service;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ElasticQueryServiceApplicationTests {
    @Test
    public void contextLoads() {
    }
}
